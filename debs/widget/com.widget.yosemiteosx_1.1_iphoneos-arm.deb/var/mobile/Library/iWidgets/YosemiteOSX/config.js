var YourName = 'Bill Gates';
