/* Copyright © 0neguy Inc. 2019 */

var $ = document;

var date = document.getElementById("date")
var temp = document.getElementById("temp")
var weatherDesc = document.getElementById("weather")
var clock = document.getElementById("clock")
var weatherImg = document.getElementById("weathericon")
var textWeather = document.getElementById("weathertext")
var right = document.getElementById("right")
var widget = document.getElementById("widget")

var dayText;
var monthText;
var finalMin;
var finalHour;

var weatherText = ["Tornado", "Tropical Storm", "Hurricane", "Thunderstorm", "Thunderstorm", "Snow", "Sleet", "Sleet", "Freezing Drizzle", "Drizzle", "Freezing Rain", "Showers", "Showers", "Flurries", "Snow", "Snow", "Snow", "Hail", "Sleet", "Dust", "Fog", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Clear", "Sunny", "Fair", "Fair", "Sleet", "Hot", "Thunderstorms", "Thunderstorms", "Thunderstorms", "Showers", "Heavy Snow", "Light Snow", "Heavy Snow", "Partly Cloudy", "Thunderstorm", "Snow", "Thunderstorm", "error"];

function prefs() {
    if (fixedWidth === 1) {
        $.body.style.width = winWidth;
    }

    date.style.color = dateColor;
    temp.style.color = tempColor;
    weatherDesc.style.color = weatherColor;
    clock.style.color = clockColor;

    widget.style.left = widgetPadding;
    widget.style.right = widgetPadding;

    widget.style.opacity = widgetOpacity;

    if (dateShow === 0) {
        date.style.display = "none";
    }
    if (tempShow === 0) {
        temp.style.display = "none";
    }
    if (clockShow === 0) {
        clock.style.display = "none";
    }
    if (weatherShow === 0) {
        weatherDesc.style.display = "none";
    }
    if (weatherIconShow === 0) {
        weatherImg.style.display = "none";
    }
}

/* 
var twelvehr = 1;
var tempColor = "#FFFFFF";
var weatherColor = "#FFFFFF";
var clockColor = "#FFFFFF";
var dateColor = "#FFFFFF";
var widgetSize = "1.0"
var widgetOpacity = "1.0"
var tempShow = 1;
var dateShow = 1;
var weatherShow = 1;
var clockShow = 1;
var weatherIconShow = 1;
var fixedWidth = 0;
var widgetPadding = "5px";
*/

function updateTime() {
    let d = new Date();
    let dayStr = d.getDay();
    let monthStr = d.getMonth();
    
    let days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
    let months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]

    dayText = days[dayStr]
    monthText = months[monthStr]
    
    if (d.getMinutes() < 10) {
        finalMin = "0" + d.getMinutes()
    } else {
        finalMin = d.getMinutes()
    }
    
    let finalHour = d.getHours();

    if (twelvehr === 1) {
        if (d.getHours() > 12) {
            finalHour -= 12;
        } else if (d.getHours() === 0) {
            finalHour = 12;
        }
    }

    setTimeout(() => {
        date.innerHTML = dayText + ", " + monthText + " " + d.getDate();
        
        clock.innerHTML = finalHour + ":" + finalMin;
    }, 800)
}

function updateWeather() {
    if (weather.conditionCode === undefined) {
        
    } else {
        temp.innerHTML = weather.temperature + "&deg;";
        weatherDesc.innerHTML = weatherText[weather.conditionCode];
        weatherImg.style.backgroundImage = "url('img/" + weather.conditionCode + ".png"
    }
    setTimeout(() => {
        if (weatherDesc.clientHeight < 18) {
            textWeather.style.marginTop = "11px";
            right.style.marginTop = "1px";
        } else {
            textWeather.style.marginTop = "0px";
            right.style.marginTop = "0px";
        }
    }, 1000);
}

setInterval(() => {
    updateTime();
}, 1000)

setInterval(() => {
    updateWeather();
}, 30000)

setTimeout(() => {
    updateWeather();
}, 1000)

document.body.onload = () => {
    updateTime();
    updateWeather();
    prefs();
    $.body.style.opacity = "1.0";
    $.body.style.transform = "scale(" + widgetSize +")";
}

