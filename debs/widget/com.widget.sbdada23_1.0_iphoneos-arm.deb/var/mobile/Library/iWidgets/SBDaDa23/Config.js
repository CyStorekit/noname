var Clock = "24h"; // choose between "12h" or "24h"
var Lang = "en"; // choose between "en", "ca", "fr", "de", "it", "ru", "pl", "pt", "cz", "no", "nl", "fi", "cn", "zh"
var lightMode = false; // true for light mode, false for dark mode
var IconSet = "Frio"; // choose your weather icon pack here
var noOfApps = "68"; // enter the number of apps on your device
var ChangeClick = false; // don't change. keep as true.
var weatherApp = "com.apple.weather"; 
var musicApp = "com.netease.cloudmusic"; 
var ClockApp = "com.apple.mobiletimer"; 


