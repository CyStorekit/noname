<!------------------------------------------------------ Configuration by Schnedi --------------------------------------------------->


// Configuration Clock //

var Clock = "12h";                // "12h" or "24h"


// Configuration Language //

var Lang = "en";                  // "ca" castellano, "it" italiano, "fr" fran�ais, "de" deutsch, "en" english