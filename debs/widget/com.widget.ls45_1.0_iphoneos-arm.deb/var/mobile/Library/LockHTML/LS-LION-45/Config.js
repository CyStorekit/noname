<!------------------------------------------------------ Configuration by Schnedi --------------------------------------------------->


// Configuration Clock //

var Clock = "24h";                // "12h" or "24h"


// Configuration Language //

var Lang = "vn";                  // "en" english, "vn" Viet Nam,