
window.addEventListener("load", function() { 
   document.body.style.width='100%';
   document.body.style.height='100%';
}, false);


function init(){
	updateClock();
	setInterval("updateClock();", 1000);
	checkSettings();
}

function checkSettings(){
	/*document.documentElement.style.setProperty('--primary', C1);//
	document.documentElement.style.setProperty('--secondary', C2);
	document.documentElement.style.setProperty('--third', C3);
	document.documentElement.style.setProperty('--fourth', C4);*/
	
	if(mu === 0){
		document.getElementById('_musCont').style.display = 'none';
	}
	
	if(ba === 0){
		document.getElementById('_battHolder').style.display = 'none';
	}
	
	if(da === 0){
		document.getElementById('_dateHolder').style.display = 'none';
	}
	
}

//------------------------- TIME FUNCTIONS ---------------------------
function updateClock() { 
	var currentTime = new Date();
	var currentHours = currentTime.getHours();
	var currentMinutes = currentTime.getMinutes();
	var currentMinutes1 = currentTime.getMinutes();
	var currentMinutesunit = currentTime.getMinutes();
	var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
	var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
	var currentYear = currentTime.getFullYear();
	//var Time24 = 1;
	
	if(Time24 === 1){
		Clock = "24h";
	}else{
		Clock = "12h";
	}
	
	if (Clock === "24h"){
		currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
	}
	if (Clock === "12h"){
		currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
		currentHours = ( currentHours == 0 ) ? 12 : currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
	}
	
	
	document.getElementById("_time").innerHTML = currentHours + ":" + currentMinutes1;
		
	document.getElementById("_month").innerHTML = shortmonths[currentTime.getMonth()];
	document.getElementById("_date").innerHTML = currentDate;
	document.getElementById("_day").innerHTML = shortdays[currentTime.getDay()];
		
}


//--------------------------- XENINFO ---------------------------
function mainUpdate(type){ 
	if(type === "weather"){
		
	}else if (type === "battery"){
		updateBattery();	  	
	}else if (type === "music"){
		checkMusic();
	}
}


//------------------------- BATTERY FUNCTIONS ---------------------------
//var batteryPercent = 100;
//var batteryCharging = 0;
//updateBattery();
//var isCharging = false;

function updateBattery() {
	"use strict";

	document.getElementById("_perc").innerHTML = batteryPercent + '%';
	
	if(batteryCharging === 1){
		//isCharging = true;
		//startAnim();
		document.getElementById("_batt").classList.add('char');
	}else{
		//isCharging = false;
		document.getElementById("_batt").classList.remove('char');
		document.getElementById("_batt").style.width = batteryPercent * 140 / 100 + 'px';
	}
	
}


