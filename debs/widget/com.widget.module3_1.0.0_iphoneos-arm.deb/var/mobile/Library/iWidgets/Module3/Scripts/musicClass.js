//auto show if music enabled
//chech if show full or simple
//if simple show info all the time

//if music enabled & weather show music & change icon
//if music enabled & settings show music
//if simple enabled dont remove current screen only show simple player & dont change icon
//------------------------- MUSIC FUNCTIONS ---------------------------
function checkMusic(){
	if (isplaying === 1) {
		document.getElementById('playPause').classList.remove("zeek-buttonplay");
		document.getElementById('playPause').classList.add("zeek-buttonpause");
	}else{
		document.getElementById('playPause').classList.remove("zeek-buttonpause");
		document.getElementById('playPause').classList.add("zeek-buttonplay");
	}
	
	if(title === "(null)"){
		document.getElementById('controls').style.display = 'none';
		document.getElementById('_title').innerHTML = '';
	}else{
		document.getElementById('controls').style.display = 'block';
		document.getElementById('_title').innerHTML = title;
		if (checkOverflow(document.getElementById('_title')) === true){
			document.getElementById('_title').classList.add("marquee");
		} else {
			document.getElementById('_title').classList.remove("marquee");
		}
	}
	
	
	if(album === "(null)"){
		//document.getElementById('_album').innerHTML = "";
		document.getElementById('musicArt').src = 'img/img.jpg';
	}else{
		//document.getElementById('_album').innerHTML = album;
		
		var xhr = new XMLHttpRequest();
		xhr.open('HEAD', "file:///var/mobile/Documents/Artwork.jpg", false);
		xhr.send();
		if (xhr.status === "404") {
			document.getElementById('musicArt').src = 'img/img.jpg';
		}else{
			document.getElementById('musicArt').src = "file:///var/mobile/Documents/Artwork.jpg?" + (new Date()).getTime();
		}
	}
	
}

function checkOverflow(el) {
	var curOverflow = el.style.overflow;
	if ( !curOverflow || curOverflow === "visible" ){
		el.style.overflow = "hidden"; 
	}
	var isOverflowing = el.clientWidth < el.scrollWidth || el.clientHeight < el.scrollHeight;
	el.style.overflow = curOverflow;
	return isOverflowing; 
} 


function playPause() {
	if ( document.getElementById('playPause').classList.contains("zeek-buttonplay")){ 
		document.getElementById('playPause').classList.remove("zeek-buttonplay");
		document.getElementById('playPause').classList.add("zeek-buttonpause");
	}else{ 
		document.getElementById('playPause').classList.remove("zeek-buttonpause");
		document.getElementById('playPause').classList.add("zeek-buttonplay");
	}
	window.location = 'xeninfo:playpause';
	document.getElementById('playPause').style.textShadow= "0px 0px 10px #FFFFFF";
	setTimeout(function (){
		document.getElementById('playPause').style.textShadow= "0px 0px 0px #FFFFFF";
	}, 200);
}
		
function next() {
	window.location = 'xeninfo:nexttrack';
	document.getElementById('next').style.textShadow= "0px 0px 10px #FFFFFF";
	setTimeout(function (){
		document.getElementById('next').style.textShadow= "0px 0px 0px #FFFFFF";
	}, 200);
}
			
function prev() {
	window.location = 'xeninfo:prevtrack';
	document.getElementById('prev').style.textShadow= "0px 0px 10px #FFFFFF";
	setTimeout(function (){
		document.getElementById('prev').style.textShadow= "0px 0px 0px #FFFFFF";
	}, 200);
}

